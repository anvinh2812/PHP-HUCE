<?php 
	function test(){
		echo "Ví dụ về hàm!";
	}

?>